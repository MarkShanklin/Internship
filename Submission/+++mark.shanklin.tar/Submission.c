/***********************************************************
* File Name     : Submission.c
* Purpose       : Submission system for the Grading Environment
* Creation Date : 06-30-2016
* Last Modified : Thu 14 Jul 2016 02:51:47 PM PDT
* Created By    : Mark Shanklin 
***********************************************************/


